/**
 * 组件安装
 * npm install gulp gulp-util gulp-less gulp-minify-css gulp-ng-template gulp-ng-annotate gulp-plumber gulp-minify-html gulp-load-plugins gulp-jshint gulp-uglify gulp-rename gulp-concat gulp-clean --save-dev
 * less less预处理
 * minifyCss css压缩
 * jshint js检查
 * uglify js压缩
 * minifyHtml  html压缩
 * rename 文件重命名
 * concat 文件合并
 * clean  清空文件夹
 * gulp-ng-annotate 这个是转换Angular控制器的插件
 * gulp-ng-template 对Angular模板存到templateCache中，可以提升页面加载，同时也起到了视图文件合并的功能
 * gulp-plumber 是一个专门为gulp而生的错误处理库，使用它可以避免gulp出错导致整个进程崩掉
 * gulp-load-plugins  自动加载
 */


var gulp = require('gulp');
var minifyHtml = require('gulp-minify-html');
var ngTemplate = require('gulp-ng-template');

gulp.task('default',['template']);


//模板压缩
gulp.task('template', function() {
    gulp.src('public/views/*.html')
        .pipe(minifyHtml({empty: true, quotes: true}))  //空格和引号处理
        .pipe(ngTemplate({
            moduleName: 'template',  //模块名
            filePath: 'templates.js',  //输出文件名
            prefix: 'public/views/',
            standalone: true
        }))
        .pipe(gulp.dest('public/apps')); //输出文件夹
});




