angular.module('uuService', [], function($httpProvider) {
    // Use x-www-form-urlencoded Content-Type
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';

    /**
     * The workhorse; converts an object to x-www-form-urlencoded serialization.
     * @param {Object} obj
     * @return {String}
     */
    var param = function(obj) {
        var query = '', name, value, fullSubName, subName, subValue, innerObj, i;

        for(name in obj) {
            value = obj[name];

            if(value instanceof Array) {
                for(i=0; i<value.length; ++i) {
                    subValue = value[i];
                    fullSubName = name + '[' + i + ']';
                    innerObj = {};
                    innerObj[fullSubName] = subValue;
                    query += param(innerObj) + '&';
                }
            }
            else if(value instanceof Object) {
                for(subName in value) {
                    subValue = value[subName];
                    fullSubName = name + '[' + subName + ']';
                    innerObj = {};
                    innerObj[fullSubName] = subValue;
                    query += param(innerObj) + '&';
                }
            }
            else if(value !== undefined && value !== null)
                query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
        }

        return query.length ? query.substr(0, query.length - 1) : query;
    };

    // Override $http service's default transformRequest
    $httpProvider.defaults.transformRequest = [function(data) {
        return angular.isObject(data) && String(data) !== '[object File]' ? param(data) : data;
    }];
}).service('uuHttp', function ($http, $q) {

    /**
     * 重写的get HTTP请求
     * @param param
     * {
     *    url:请求的地址
     *    params:要携带的参数
     * }
     * @returns {d.promise|Function|*|promise|k.promise|{then, catch, finally}}
     */
    function getHttp(param) {
        var deferred = $q.defer(),
            promise = deferred.promise;

        $http({
            method: 'GET',
            url: param.url,
            withCredentials: true,
            params: (function(){(typeof param.data == "undefined" ? param.data = {"se": sessionStorage.getItem(SE)} : param.data['se'] = sessionStorage.getItem(SE)); return param.data;})()
        }).success(function(data,status,headers,config){
            //执行成功
            deferred.resolve(data);
        }).error(function(data,status,headers,config){
            //执行失败
            deferred.reject();
        });

        return promise;
    }

    /**
     * 重写的POST HTTP请求
     * @param param
     * {
     *    url:请求的地址
     *    data:要携带的参数
     * }
     * @returns {d.promise|Function|*|promise|k.promise|{then, catch, finally}}
     */
    function postHttp(param) {
        var deferred = $q.defer(),
            promise = deferred.promise;

        $http({
            method: 'POST',
            url: param.url,
            withCredentials: true,
            params: {se:sessionStorage.getItem(SE)},
            data: (function(){typeof param.data == "undefined" ? param.data = {se: sessionStorage.getItem(SE)} : param.data.se = sessionStorage.getItem(SE); return param.data;})()
        }).success(function(data,status,headers,config){
            //执行成功
            deferred.resolve(data);
        }).error(function(data,status,headers,config){
            //执行失败
            deferred.reject();
        });

        return promise;
    }

    /**
     * 重写的JSONP HTTP请求
     * @param param
     * {
     *    url:请求的地址
     *    callback:回调函数
     * }
     */
    function jsonPHttp(param) {
        var _browser={
                ie:/msie/.test(window.navigator.userAgent.toLowerCase()),
                moz:/gecko/.test(window.navigator.userAgent.toLowerCase()),
                opera:/opera/.test(window.navigator.userAgent.toLowerCase()),
                safari:/safari/.test(window.navigator.userAgent.toLowerCase())
            },
            _script=document.createElement('script');

        _script.setAttribute('src',param.url);
        _script.async = param.async ? param.async : true;
        document.getElementsByTagName('head')[0].appendChild(_script);

        if(_browser.ie){
            _script.onreadystatechange=function(){
                if(this.readyState === 'loaded' || this.readyState === 'complete'){
                    callbackOK();
                }
            };
        } else if(_browser.moz){
            _script.onload=function(){
                callbackOK();
            };
        } else{
            callbackOK();
        }

        function callbackOK(){
            param.callback(eval("("+ jsonStr +")"));
            document.getElementsByTagName('head')[0].removeChild(_script);
        }

    }

    return {
        get: getHttp,
        post: postHttp,
        jsonp: jsonPHttp
    }

}).service('dataUrl', function(){

    return {
        dataUrl: "",
        dataBack: ""
    }
});
