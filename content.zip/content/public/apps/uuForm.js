angular.module('form', ['uuService']).controller('formContr', ['$scope', '$timeout', '$rootScope', 'uuHttp', 'dataUrl', function ($scope,$timeout,$rootScope,uuHttp,dataUrl) {
    $scope.optionsObj = {};
    $scope.ckeditorObj = {};
    $rootScope.ckeditor = [];

    getInitDate(dataUrl.dataUrl);
    function getInitDate(url){
        uuHttp.get({url:url}).then(function(data){
                if (data.code === 0) {
                    console.log(data);
                    $scope.submitUrl = data.data.url;
                    $scope.formName = data.data.name;
                    $scope.back = data.data.back;
                    //页头数据
                    if(data.data.header){
                        $scope.header = data.data.header;
                        $scope.headerOpers = data.data.header.operation;
                        $scope.header1 = data.data.header.pagelink[0];
                        $scope.header2 = data.data.header.pagelink.slice(1);
                    }

                    createForm(data.data);
                    dataUrl.dataUrl = "";
                } else if(data.code <= 4){
                    window.location.href =  loginUrl;
                } else {
                    alert(data.message);
                }
            });
    }

    function createForm(data){
        $scope.$broadcast("render.form", {formData:data});
    }

    /****************************************************************************************
     *                                      页头操作
     *****************************************************************************************/
    $scope.headerClick = function(url,type){
        if(url !== ""){
            dataUrl.dataUrl = url;
        }
        var hash = window.location.hash;
        switch (type){
            case "getTable" :
                if(url === ""){
                    break;
                } else {
                    window.location.href = '#/uptable';
                    break;
                }
            case "upTable" :
                window.location.href = '#/uptable';
                break;
            case "getForm" :
                if(url === ""){
                    break;
                }  else {
                    if(hash === "#/upform"){
                        getInitDate(dataUrl.dataUrl);
                    } else {
                        window.location.href = '#/upform';
                    }
                    break;
                }
            case "upForm" :
                if(hash === "#/upform"){
                    getInitDate(dataUrl.dataUrl);
                } else {
                    window.location.href = '#/upform';
                }
                break;
        }
    };

    $scope.backList = function(){
       window.history.back();
    };

    //提交表单
    var isOK = true;
    $scope.submitForm = function(){
        var data = {};
        if($rootScope.ckeditor.length > 0){
            for(var i = 0; i < $rootScope.ckeditor.length; i++){
                data[$("#"+$rootScope.ckeditor[i].id).attr("input-name")] = $rootScope.ckeditor[i].obj.document.getBody().getHtml();
            }
        }
        $(".getValue").each(function(){
            data[$(this).attr("input-name")] = $(this).val();
        });

        $(".getCheckValue").each(function(){
            var inputName = $(this).attr("input-name");
            $(this).find(".checkInp").each(function(){
                if($(this).val()) {
                    if(data[inputName] == undefined){
                        data[inputName] = $(this).val();
                    } else {
                        data[inputName] += "," + $(this).val();
                    }
                }
            });
        });

        $(".getRadioValue").each(function(){
            data[$(this).attr("input-name")] = $(this).find(".radioInp:checked").val();
        });

        data["dataForm"] = JSON.stringify(data);

        console.log(data);

        if(isOK){
            isOK = false;
            uuHttp.post({url:$scope.submitUrl,data:data}).then(function(data){
                isOK = true;
                if(data.code === 0){
                    alert("保存成功");
                    if($scope.back == "false"){

                    } else {
                        window.history.back();
                    }

                } else if(data.code <= 4){
                    window.location.href =  loginUrl;
                } else {
                    alert(data.message);
                }
            }, function(){
                isOK = true;
            });
        }

    };

}]).directive('text', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/text.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作

        }
    }
}]).directive('hidden', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/hidden.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作

        }
    }
}]).directive('longText', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/longText.html", //引用外部模块
        scope: {
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorTip : '@', //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作

        }
    }
}]).directive('number', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/number.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs){
            $scope.isNum = function (num){
                return Number.parseInt(num);
            };
        },
        link: function (scope, element, attr) {  //DOM操作

        }
    }
}]).directive('map', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/map.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs){

            typeof $scope.defaultValue == "undefined" ? $scope.mapcenter = "113.9532851772156,22.54079806044805" : $scope.mapcenter = $scope.defaultValue;

            var geocoder,point,address,lng,lat;

            /**
             * 打开地图弹窗
             */
            $scope.openMap = function(){
                $element.find(".formwin").show();

                initMap($scope.name+"Map");
                $element.find('#btnSearch').click(function() {
                    doSearch();
                });

                $element.find('#txtAddress,#txtCity').keyup(function(event) {
                    if (event.which == 13) {
                        doSearch();
                    }
                });
            };

            /**
             * 初始化地图
             */
            function initMap(mapId) {

                //中心点
                var latLng = $scope.mapcenter.split(",");
                var center = new qq.maps.LatLng(latLng[1],latLng[0]);

                //创建地图
                var map = new qq.maps.Map(document.getElementById(mapId),{
                    center: center,
                    zoom: 13
                });

                //选择点标志
                var marker = new qq.maps.Marker({
                    position: center,
                    map: map,
                    visible : true,
                    draggable : true
                });

                //拖动到新的定位点
                qq.maps.event.addListener(marker,"dragend",function(event){
                    center = event.latLng;
                    lng = center.lng;
                    lat = center.lat;
                    map.panTo(center);
                    //地址转换
                    geocoder.getAddress(center);
                });



                //搜索需要
                geocoder = new qq.maps.Geocoder({
                    complete : function(result) {
                        lng = result.detail.location.lng;
                        lat = result.detail.location.lat;
                        map.setCenter(result.detail.location);
                        marker.setPosition(result.detail.location);
                        point = result.detail.location;
                        address = result.detail.address;
                    }
                });



            }

            //执行地点搜索
            function doSearch() {
                var city = $element.find('#txtCity').val();
                var address = $element.find('#txtAddress').val();
                if (city == '') {
                    alert('请输入城市名称!');
                    return;
                }
                geocoder.getLocation(city + ' ' + address);
            }


            /**
             * 确认新地点
             */
            $scope.confirmMap = function(target){
                $scope.mapcenter = lng + "," + lat;
                $element.find("input.getValue[name='map']").val($scope.mapcenter);
                $element.find("input.getValue[name='address']").val(address);
                $element.find(".event-mapTc").hide();
            };

            //关闭弹窗
            $scope.closeWin = function(){
                $element.find(".event-mapTc").hide();
            };
        },
        link: function (scope, element, attr) {  //DOM操作

        }
    }
}]).directive('textArea', ['$rootScope', '$timeout', function ($rootScope,$timeout) {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/textArea.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            ckeditorObj : '=',
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {
            $scope.ckeditorObjs = $scope.ckeditorObj[$scope.name];
        },
        link: function (scope, element, attrs) {  //DOM操作
            var ckeditor = {};
            $timeout(function() {
                ckeditor.id = scope.name;
                ckeditor.obj = CKEDITOR.replace(scope.name);
                $rootScope.ckeditor.push(ckeditor);
                CKEDITOR.instances[scope.name].setData(scope.ckeditorObjs);
            },100);

        }
    }
}]).directive('choseBox', ['$timeout', 'uuHttp', '$compile', function ($timeout,uuHttp,$compile) {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        transclude: true,  //允许指令嵌套
        templateUrl: "public/views/choseBox.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            optionsObj: '=',
            ajaxUrl: '@',
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {
            $scope.optionsObjs = $scope.optionsObj[$scope.name];
            $scope.ajaxUrlOption = function(v){
                uuHttp.get({url:$scope.ajaxUrl,data:{id:v}}).then(function(data){
                    for(var i = 0; i < data.data.name.length; i++){
                        if(i == 0){
                            $scope.optionsObj[data.data.name[i]] = data.data.options;
                            $compile($element.next())($scope)
                        } else {
                            $scope.optionsObj[data.data.name[i]] = [];
                            $compile($element.next().next())($scope)
                        }

                    }
                });
            }

        },
        link: function (scope, element, attr) {  //DOM操作
            $timeout(function(){
                element.find(".chosen-select option:eq(0)").remove();
                element.find(".chosen-select").chosen({width: "100%",allow_single_deselect:true,search_contains:true});
            },1);
        }
    }
}]).directive('onoff', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/onoff.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作
            if(scope.defaultValue == "1") {
                element.find(".getValue").prop("checked",true);
            } else {
                element.find(".getValue").prop("checked",false);
            }
        }
    }
}]).directive('colorPicker', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/colorPicker.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作
            element.find("#colorpicker").spectrum({
                preferredFormat: "rgb",
                showInput: true,
                color: scope.defaultValue
            });
        }
    }
}]).directive('colorPickera', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/colorPicker.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作
            element.find("#colorpicker").spectrum({
                preferredFormat: "rgb",
                showInput: true,
                showAlpha: true,
                color: scope.defaultValue
            });
        }
    }
}]).directive('dateTime', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/datetime.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作
            var options = {
                format: 'YYYY-MM-DD HH:mm',
                singleDatePicker: true,
                timePicker: true,
                timePicker12Hour: false,
                timePickerIncrement: 1,
                startDate: moment(),
                applyClass: "btn-sm btn-success",
                cancelClass: "btn-sm btn-default",
                locale: {
                    applyLabel: "确认",
                    cancelLabel: "返回",
                    daysOfWeek: ['日', '一', '二', '三', '四', '五', '六'],
                    monthNames: ['1月', '3月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
                }
            };
            element.find("#datetimepicker1").daterangepicker(options, function (start, end, label) {
                //stm = start.format('YYYY-MM-DD');
                //etm = end.format('YYYY-MM-DD');
            });
        }
    }
}]).directive('date', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/date.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作
            var options = {
                format: 'YYYY-MM-DD',
                singleDatePicker: true,
                startDate: moment(),
                locale: {
                    daysOfWeek: ['日', '一', '二', '三', '四', '五', '六'],
                    monthNames: ['1月', '3月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
                }
            };

            element.find("#datepicker1").daterangepicker(options,function (start, end, label) {
                //stm = start.format('YYYY-MM-DD');
                //etm = end.format('YYYY-MM-DD');
            });
        }
    }
}]).directive('checkbox', ['$timeout', function ($timeout) {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/checkbox.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {
            var checkbox = JSON.parse($scope.options),
                defaultArr = $scope.defaultValue.split(",");
            for(var n = 0; n < checkbox.length; n++){
                for(var i = 0; i < defaultArr.length; i++){
                    if(checkbox[n].value == defaultArr[i]){
                        checkbox[n].default = defaultArr[i];
                    }
                }
            }
            $scope.checkbox = checkbox;
        },
        link: function (scope, element, attrs) {  //DOM操作
            $timeout(function(){
                element.find(".checkInp").each(function(){
                    if($(this).val()){
                        $(this).prop("checked",true);
                    }
                });
            },1);
        }
    }
}]).directive('radio', ['$timeout', function ($timeout) {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/radio.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {
            $scope.checkbox = JSON.parse($scope.options);
        },
        link: function (scope, element, attrs) {  //DOM操作
            $timeout(function(){
                element.find(".radioInp").each(function(){
                    if($(this).val() == scope.defaultValue){
                        $(this).prop("checked",true);
                    }
                });
            },1);
        }
    }
}]).directive('radioColor', ['$timeout', function ($timeout) {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/radioColor.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {
            $scope.checkbox = JSON.parse($scope.options);
        },
        link: function (scope, element, attrs) {  //DOM操作
            $timeout(function(){
                element.find(".radioInp").each(function(){
                    if($(this).val() == scope.defaultValue){
                        $(this).prop("checked",true);
                    }
                });
            },1);
        }
    }
}]).directive('dateRange', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/dateRange.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@' //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作

            var options = {
                format: 'YYYY-MM-DD',
                "applyClass": "btn-sm btn-success",
                "cancelClass": "btn-sm btn-default",
                locale: {
                    applyLabel: "确认",
                    cancelLabel: "返回",
                    customRangeLabel: '选择',
                    separator: ' - ',
                    fromLabel: '起始日期',
                    toLabel: '结束日期',
                    daysOfWeek: ['日', '一', '二', '三', '四', '五', '六'],
                    monthNames: ['1月', '3月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
                },
                ranges: {
                    '今天': [moment(), moment()],
                    /*'昨天': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],*/
                    '最近7天': [moment().subtract(6, 'days'), moment()],
                    '最近30天': [moment().subtract(29, 'days'), moment()]
                    /*'本月': [moment().startOf('month'), moment().endOf('month')],
                     '上月': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]*/
                }
            };

            element.find("#daterangepicker1").daterangepicker(options, function (start, end, label) {
                //stm = start.format('YYYY-MM-DD');
                //etm = end.format('YYYY-MM-DD');
            });
        }
    }
}]).directive('qrimg', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/qr.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            ajaxUrl:'@',
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@'   //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作

        }
    }
}]).directive('tags', [function () {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/tags.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            ajaxUrl:'@',
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@'   //options 选项
        },
        controller: function($scope, $element, $attrs) {
            $scope.tagsUser = $scope.defaultValue.split(",");
            $scope.tagsSys = JSON.parse($scope.options);
        },
        link: function (scope, element, attrs) {  //DOM操作
            element.on("click", ".writePlace", function(){
                $("#inputDiv").focus();
            }).on("click", ".uuLabel ul li", function(){
                var i,labelData = getLabelObj(),isTrue = true;

                for(i = 0; i < labelData.length; i++){
                    if(labelData[i].text == $(this).text()){
                        isTrue = false;
                        labelData[i].obj.parent().addClass("twinklingAni");
                        setTimeout(function(){
                            labelData[i].obj.parent().removeClass("twinklingAni");
                        }, 1000);
                        break;
                    }
                }
                if(isTrue){
                    element.find(".inputDiv").parent().before("<li><span class='uuLabelText'>"+$(this).text()+"</span><span>×</span></li>");
                }

            }).on("keydown", ".inputDiv", function(e){
                var labelStr  =  $(this).val(),
                    tempStr = labelStr.replace(/(^\s*)|(\s*$)/g, ""),
                    stop = e.which,
                    i,
                    labelData = getLabelObj(),
                    isTrue = true;
                if(stop == '13' || stop == '9'){
                    if(tempStr.replace(/(^\s*)|(\s*$)/g, "") != ""){
                        for(i = 0; i < labelData.length; i++){
                            if(labelData[i].text == labelStr){
                                isTrue = false;
                                labelData[i].obj.parent().addClass("twinklingAni");
                                setTimeout(function(){
                                    labelData[i].obj.parent().removeClass("twinklingAni");
                                }, 1000);
                                break;
                            }
                        }
                        if(isTrue){
                            element.find(".inputDiv").parent().before("<li><span class='uuLabelText'>"+ labelStr +"</span><span>×</span></li>");
                            $(this).val("");
                        }
                    }
                }
            }).on("click", ".writePlace ul li span", function(e){
                e.stopPropagation();
                $(this).parent().remove();
            });

            function getLabelObj(){
                var data = [];
                element.find(".writePlace ul li span.uuLabelText").each(function(){
                    data.push({obj:$(this),text:$(this).text()});
                });
                return data;
            }

        }
    }
}]).directive('qr', ['$timeout', 'uuHttp', function ($timeout,uuHttp) {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/qr.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            ajaxUrl:'@',
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@'   //options 选项
        },
        controller: function($scope, $element, $attrs) {

        },
        link: function (scope, element, attrs) {  //DOM操作

            getQr();
            function getQr(){
                uuHttp.post({url:scope.ajaxUrl}).then(function(data){
                    if (data.error == 0) {
                        qrTime = $timeout(function(){
                            getQr()
                        }, 5000);
                    } else if(data.error == 200){
                        $timeout.cancel(qrTime);
                        element.hide();
                        element.parents("#formID").find('input[input-name="p_weixin_name"]').val(data.data.nickname);
                        element.parents("#formID").find('input[input-name="p_manager_openid"]').val(data.data.openid).attr("readonly","readonly");
                        var $imgDIv = element.parents("#formID").find('input[input-name="p_img"]').parents(".slimScrollDiv");
                        var pImg = $imgDIv.find(".cloneLi li").clone();
                        createDom(pImg, data.data.headimgurl);
                        $imgDIv.find(".submitImg").val(data.data.headimgurl);
                        function createDom(obj, filesUrl) {
                            obj.find(".imgList").attr("value", filesUrl);
                            obj.find("href").attr("href", filesUrl);
                            obj.find("img").attr("src", filesUrl);
                            $imgDIv.find(".imgValue").append(obj);
                        }
                        console.log(data.data);
                    }
                });
            }
        }
    }
}]).directive('imgUpload', ['$timeout', function ($timeout) {
    return {
        restrict: 'AE',  //定义指令的类型
        replace:true, //去除指令标签
        templateUrl: "public/views/imgUpload.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@'   //options 选项
        },
        controller: function($scope, $element, $attrs) {
            var $thisForm;

            if($scope.defaultValue != "null" && typeof $scope.defaultValue != "undefined"){
                $scope.imgs = $scope.defaultValue.split(";");
            }

            var options = {
                target:        'formImg'+$scope.name,   // 需要刷新的区域
                //beforeSubmit:  showRequest,  // 提交前调用的方法
                success:function(data){
                    var $this = $thisForm.parents(".uploadImg"),
                        files = data.datastr,
                        multiple = $('#upload'+$scope.name).attr("multiple"), i = 0; //判断是单张还是多张

                    //生成预览
                    if(typeof(multiple) == "undefined"){
                        if($this.find(".imgValue li").length === 2){
                            var li1 = $this.find(".imgValue li.imgLi");
                            li1.find(".imgList").attr("value",files);
                            li1.find(".cboxElement").attr("href",files);
                            li1.find("img").attr("src",files);
                        } else {
                            createDom(files[0].url);
                        }
                    } else {
                        for(i = 0; i < files.length; i++){
                            (function(i){
                                createDom(files[i].url);
                            })(i);
                        }
                    }

                    var imgList = $this.find(".imgValue .imgList"),
                        imgStr = '';

                    for(i = 0; i < imgList.length; i++){
                        imgStr += $(imgList[i]).val() + ";";
                    }

                    function createDom(filesUrl){
                        var obj = $this.find(".cloneLi li").clone();
                        obj.find(".imgList").attr("value",filesUrl);
                        obj.find("href").attr("href",filesUrl);
                        obj.find("img").attr("src",filesUrl);
                        $this.find(".imgValue").append(obj);
                    }

                    imgStr = imgStr.substring(0,imgStr.length-1);
                    $this.find(".submitImg").attr("value", imgStr);
                    $this.find(".queueID").css("width", "100%").text("上传完成");

                    $timeout(function(){
                        $this.find(".queueID").css("width", "0").text("");
                        $this.find(".swfupload-progress").hide();
                    },500);

                },
                url: 'https://oapi.playwx.com/api/res/UploadFile.do?token=1c954693fbedf5bb517bc2e3d21b3a25&fileType=1',         // 提交的URL, 默认使用FORM  ACTION
                type: 'POST',
                dataType:  'json',
                //clearForm: true        // 是否清空form
                resetForm: true,        // 是否重置form
                timeout:   30000
            };
            $scope.imgUpload = function(e){
                $('#'+$scope.name).ajaxSubmit(options);
                $thisForm = $('#upload'+$scope.name);
                $thisForm.parents(".uploadImg").find(".swfupload-progress").show()
            };

        },
        link: function (scope, element, attrs) {  //DOM操作

            element.on("click", ".repSwfupload", function(){
                $(this).next().find("input").trigger("click");
            }).on("click", ".tools-bottom", function(){
                var $obj = $(this).parents(".imgValue");
                $(this).parents(".imgLi").remove();
                submitImgValue($obj);
            });

            function submitImgValue(obj){
                var imgList = $(obj).find(".imgList");
                var imgStr = '';
                for(var i = 0; i < imgList.length; i++){
                    imgStr += $(imgList[i]).val() + ";";
                }
                imgStr = imgStr.substring(0,imgStr.length-1);
                $(obj).find(".submitImg").attr("value", imgStr);
            }

            setTimeout(function(){
                $(".ui-sortable").sortable({
                    update: function(e, u){
                        submitImgValue($(e.target));
                    }
                });
            },500);

        }
    }
}]).directive('musicUpload', ['$timeout', function ($timeout) {
    return {
        replace:true, //去除指令标签
        templateUrl: "public/views/musicUpload.html", //引用外部模块
        scope: {  //作用域
            label : '@', //label 标签名
            name : '@',  //fieldName 字段名
            tip : '@',  // tip 提示
            type : '@', //inputType 类型
            required : '@', //是否必填
            validation : '@',  // validation 验证
            maxLength : '@',  //maxLength 最长限制
            minLength : '@',  //minLength 最短限制
            defaultValue : '@',  //defaultValue 默认值
            errorMessages : '@',  //errorTip 错误提示
            errorTip : '@',  //errorTip 错误提示
            options : '@'   //options 选项
        },
        controller: function($scope, $element, $attrs) {
            var $thisForm;

            if($scope.defaultValue != "null" && typeof $scope.defaultValue != "undefined"){
                $scope.musics = $scope.defaultValue.split(";");
            }

            var options = {
                target:        'formMusic'+$scope.name,   // 需要刷新的区域
                success:function(data){
                    var $this = $thisForm.parents(".uploadMusic");
                    $this.find(".queueID").css("width", "100%").text("上传完成");
                    $timeout(function(){
                        $this.find(".queueID").css("width", "0").text("");
                        $this.find(".swfupload-progress").hide();
                    },500);

                    if(data.errorcode == 0){
                        var files = data.datastr[0].url;
                        $this.find("#musicSrc"+$scope.name).attr("src",files);
                        $this.find(".submitMusic").attr("value", files);
                        $this.find("#musicSrcTip"+$scope.name).hide();
                    } else {
                        alert(data.message);
                    }
                },
                url: 'http://oapi.playwx.com/api/res/UploadFile.do?token=1c954693fbedf5bb517bc2e3d21b3a25&fileType=2',
                type: 'POST',       // 'get' or 'post', override for form's 'method' attribute
                dataType:  'json',        // 'xml', 'script', or 'json' (expected server response type)
                resetForm: true,        // 是否重置form
                timeout:   300000
            };

            $scope.musicUpload = function(){
                $('#'+$scope.name).ajaxSubmit(options);
                $thisForm = $('#upload'+$scope.name);
                $thisForm.parents(".uploadMusic").find(".swfupload-progress").show()
            };

            $scope.deleteMusic = function(e){
                $(e.target).parents(".uploadMusic").find("#musicSrc"+$scope.name).attr("src","").end().find("#musicSrcTip"+$scope.name).show();
            }
        },
        link: function (scope, element, attrs) {  //DOM操作
            element.on("click", ".repSwfupload", function(){
                $(this).next().find("input").trigger("click");
            });
            $timeout(function(){
                element.find("#musicSrc"+scope.name).attr("src",scope.defaultValue);
            },100);
        }
    }
}]).directive('uuForm', ['$compile', function($compile){

    /**
     * 连接函数
     * @param scope 作用域
     * @param element  作用元素
     * @param attr  元素属性
     */
    function link(scope, element, attr) {

        /**
         * 生成表单
         */
        function getFromData(formData) {

            //表单数据
            var formFields = formData.fields;

            //拼接指令DIV字符串
            var addDiv = "";

            for (var i = 0; i < formFields.length; i++) {
                var inputType = formFields[i].inputType;
                switch (inputType) {
                    case "text" :
                        addDiv += directivesType("text", formFields[i]);
                        break;
                    case "email" :
                        addDiv += directivesType("text", formFields[i]);
                        break;
                    case "longText" :
                        addDiv += directivesType("long-Text", formFields[i]);
                        break;
                    case "tel" :
                        addDiv += directivesType("text", formFields[i]);
                        break;
                    case "hidden" :
                        addDiv += directivesType("hidden", formFields[i]);
                        break;
                    case "number" :
                        addDiv += directivesType("number", formFields[i]);
                        break;
                    case "date" :
                        addDiv += directivesType("date", formFields[i]);
                        break;
                    case "checkbox" :
                        addDiv += directivesType("checkbox", formFields[i]);
                        break;
                    case "radio" :
                        addDiv += directivesType("radio", formFields[i]);
                        break;
                    case "textArea" :
                        scope.ckeditorObj[formFields[i].fieldName] = formFields[i].defaultValue;
                        addDiv += directivesType("text-Area", formFields[i]);
                        break;
                    case "dropdownList" :
                        scope.optionsObj[formFields[i].fieldName] = formFields[i].options;
                        addDiv += directivesType("chose-Box", formFields[i]);
                        break;
                    case "onoff" :
                        addDiv += directivesType("onoff", formFields[i]);
                        break;
                    case "img" :
                        addDiv += directivesType("img-Upload", formFields[i]);
                        break;
                    case "music" :
                        addDiv += directivesType("music-Upload", formFields[i]);
                        break;
                    case "qr" :
                        addDiv += directivesType("qr", formFields[i]);
                        break;
                    case "qrimg" :
                        addDiv += directivesType("qrimg", formFields[i]);
                        break;
                    case "map" :
                        addDiv += directivesType("map", formFields[i]);
                        break;
                    case "dateTime" :
                        addDiv += directivesType("date-Time", formFields[i]);
                        break;
                    case "dateRange" :
                        addDiv += directivesType("date-Range", formFields[i]);
                        break;
                    case "colorPicker" :
                        addDiv += directivesType("color-Picker", formFields[i]);
                        break;
                    case "colorPickera" :
                        addDiv += directivesType("color-Pickera", formFields[i]);
                        break;
                    case "radioColor" :
                        addDiv += directivesType("radio-Color", formFields[i]);
                        break;
                    case "tags" :
                        addDiv += directivesType("tags", formFields[i]);
                        break;
                }
            }

            addDiv += '<div class="form-actions"><div class="uuFormSubmit">' +
            '<button id="btnSubmit" class="btn btn-info" ng-click="submitForm()" ng-disabled="form01.$invalid">' +
            '<i class="ace-icon fa fa-check bigger-90"></i>保存</button>' +
            '<button id="btnReset" class="btn" ng-click="backList()"><i class="ace-icon fa fa-undo bigger-90"></i>返回</button></div></div>';

            //转换成JQuery对象
            var $div = $(addDiv);

            //追加DIV
            $compile($div)(scope);
            element.html("").prepend($div);
        }

        /**
         * @param type 传入的表单字段类型
         * @param data 传入的表单字段数据
         * @returns {string}
         */
        function directivesType(type, data) {

            var ngDiv = '';

            //@数据绑定只能传字符串，如果是数据绑定要用{{}}
            var options = JSON.stringify(data.options);

            switch (type) {
                case "chose-Box" :
                    ngDiv = '<div ' + type + ' ' +
                    'label="' + data.label + '" ' +
                    'name="' + data.fieldName + '" ' +
                    'tip="' + data.tip + '" ' +
                    'type="' + data.inputType + '" ' +
                    'required="' + data.required + '" ' +
                    'validation="' + data.validation + '"' +
                    'max-length="' + data.maxLength + '"' +
                    'min-length="' + data.minLength + '"' +
                    'default-value="' + data.defaultValue + '"' +
                    'ajax-url="' + data.ajaxUrl +'"' +
                    'error-tip="' + data.errorTip + '"' +
                    'options-obj="optionsObj"></div>';
                    break;
                case "text-Area" :
                    ngDiv = '<div ' + type + ' ' +
                    'label="' + data.label + '" ' +
                    'name="' + data.fieldName + '" ' +
                    'tip="' + data.tip + '" ' +
                    'type="' + data.inputType + '" ' +
                    'required="' + data.required + '" ' +
                    'validation="' + data.validation + '"' +
                    'max-length="' + data.maxLength + '"' +
                    'min-length="' + data.minLength + '"' +
                    'ajax-url="' + data.ajaxUrl +'"' +
                    'error-tip="' + data.errorTip + '"' +
                    'ckeditor-obj="ckeditorObj"></div>';
                    break;
                default :
                    ngDiv = '<div ' + type + ' ' +
                    'label="' + data.label + '" ' +
                    'name="' + data.fieldName + '" ' +
                    'tip="' + data.tip + '" ' +
                    'type="' + data.inputType + '" ' +
                    'required="' + data.required + '" ' +
                    'validation="' + data.validation + '"' +
                    'max-length="' + data.maxLength + '"' +
                    'min-length="' + data.minLength + '"' +
                    'default-value="' + data.defaultValue + '"' +
                    'ajax-url="' + data.ajaxUrl +'"' +
                    'error-tip="' + data.errorTip + '"' +
                    'options=' + options + '></div>';
            }

            //指令DIV
            return ngDiv;
        }

        scope.$on("render.form", function(obj,args){
            getFromData(args.formData);
        });
    }

    return {
        restrict: 'A',
        link: link
    }
}]);