angular.module('uuApp', ['ngRoute','uuService','table','form','template']).run(['$rootScope', 'dataUrl', '$timeout', function ($rootScope,dataUrl,$timeout) {
    $rootScope.$on('$routeChangeStart', function(evt, next, current) {
        $timeout.cancel(qrTime);
    });

    $rootScope.$on('$routeChangeSuccess', function(evt, next, current) {
        eval(routerChangeStr);
    });

}]).config(['$routeProvider', function($routeProvider) {

    eval(routerStr);

}]).controller('appContr', ['$scope', 'uuHttp', 'dataUrl', function ($scope,uuHttp,dataUrl) {

    $scope.getDateUrl = function(data){
        dataUrl.dataUrl = data;
        sessionStorage.urlData = data;
    };
    $scope.navs = navData;

}]).filter('filTrueFalse', function () {
    return function(v){
        var value = ""+v;
        switch (value){
            case "true" :
                return "是";
                break;
            case "false" :
                return '否';
                break;
        }

    }
});
