angular.module('table', ['uuService']).controller('tableContr', ['$scope', '$http', '$sce', 'uuHttp', 'dataUrl', function ($scope,$http,$sce,uuHttp,dataUrl) {

    /****************************************************************************************
     *                                      全局变量
     *****************************************************************************************/
    var data = {};

    //分页请求接口
    $scope.pageDataUrl = dataUrl.dataUrl;
    getInitDate(dataUrl.dataUrl);
    function getInitDate(url){

        uuHttp.get({url:url}).then(function(data){
            if (data.code === 0) {
                //表格初始数据
                uploadData(data.data);
                dataUrl.dataUrl = "";
            } else if(data.code <= 4){
                window.location.href =  loginUrl;
            } else {
                alert(data.message);
            }
        });
    }

    //总页数
    var allPage = 1;

    /**
     * 切换标签
     * @param url 请求数据的地址
     * @param target 请求的事件源
     */
    $scope.getLabelData = function(url,target){
        uuHttp.get({url:url}).then(function(data){
            if (data.code === 0) {
                $(target).parents(".label-head").find(".active").removeClass("active");
                $(target).addClass("active");
                $scope.pageDataUrl = url;
                uploadData(data.data);
            } else if(data.code <= 4){
                window.location.href =  loginUrl;
            } else {
                alert(data.message);
            }
        });
    };

    /**
     * 删除数据
     */
    function delTableData(url){
        uuHttp.get({url:url}).then(function(data){
            if (data.code === 0) {
                getInitDate($scope.pageDataUrl);
            } else if(data.code <= 4){
                window.location.href =  loginUrl;
            } else {
                alert(data.message);
            }
        });
    }

    /**
     * 更新链接上的参数
     * @param href
     * @param paramName
     * @param paramValue
     * @returns {string}
     */
    function updateUrlParam(href, paramName, paramValue){
        var urlArr = href.split('#'),
            url = urlArr[0];
        if (/\?/g.test(url)) {
            var reg = new RegExp("([?&]+)" + paramName + "=([^&]*)", "gi"),
                rs = reg.exec(url);
            if (rs) {

                if (paramValue === null || paramValue === 'null') {
                    url = url.replace(reg, '');
                    if (url.indexOf('?') === -1 || url.indexOf('&') < url.indexOf('?')) {
                        url = url.replace('&', '?');
                    }
                } else {
                    url = url.replace(reg, rs[1] + paramName + "=" + paramValue);
                }
            } else {
                url += "&" + paramName + "=" + paramValue;
            }
        } else if (paramName) {
            url += "?" + paramName + "=" + paramValue;
        }
        urlArr[0] = url;
        return urlArr.join('#');
    }

    /**
     * 更新表格数据
     * @param data
     * @param page
     */
    function uploadData(data,page){

        //页头数据
        if(data.header){
            $scope.header = data.header;
            $scope.headerOpers = data.header.operation;
            $scope.headerOpersTwo = data.header.operationTwo;
            $scope.header1 = data.header.pagelink[0];
            $scope.header2 = data.header.pagelink.slice(1);
        }

        //标签数据
        $scope.labels = data.label;

        //搜索数据
        $scope.searchs = data.search;

        if(page){

        } else {
            //总数
            $scope.counts = data.count;

            //每页数据数
            $scope.mpages = data.mpage;

            //初始化页码
            $scope.startdata = 1;
            $scope.enddata = data.mpage;

            //页数
            allPage = 1;
            $scope.pagenums = pageNum(data.mpage, data.count);

            //默认选中第一页数据
            $scope.isShowClass = 1;
            $scope.isDisabledPrev = true;
            $scope.isDisabledNext = $scope.pagenums.length <= 1;

        }


        $scope.$broadcast("render.table", {columnth:data.columnth,columntd:data.columntd,search:data.search});
    }


    /****************************************************************************************
     *                                      页头操作
     *****************************************************************************************/
    $scope.headerClick = function(url,type){

        if(url !== ""){
            dataUrl.dataUrl = url;
        }
        var hash = window.location.hash;

        switch (type){
            case "getTable" :
                if(url === ""){
                    break;
                } else {
                    sessionStorage.urlTableData = dataUrl.dataUrl;
                    if(hash === "#/uptable"){
                        $scope.pageDataUrl = dataUrl.dataUrl;
                        getInitDate(dataUrl.dataUrl);
                    } else {
                        window.location.href = '#/uptable';
                    }
                    break;
                }
            case "upTable" :
                sessionStorage.urlTableData = dataUrl.dataUrl;
                if(hash === "#/uptable"){
                    $scope.pageDataUrl = dataUrl.dataUrl;
                    getInitDate(dataUrl.dataUrl);
                } else {
                    window.location.href = '#/uptable';
                }
                break;
            case "getForm" :
                if(url === ""){
                    break;
                } else {
                    sessionStorage.urlFormData = dataUrl.dataUrl;
                    window.location.href = '#/upform';
                    break;
                }
            case "upForm" :
                sessionStorage.urlFormData = dataUrl.dataUrl;
                window.location.href = '#/upform';
                break;
            case "location" :
                window.location.href = updateUrlParam(window.location.href.split("#")[0], "navurl", encodeURIComponent(url));
                break;
            case "back" :
                window.history.back();
                break;
        }
    };



    /****************************************************************************************
     *                                      分页操作
     *****************************************************************************************/

    /**
     * 分页页数函数
     * @param mpage 每页数量
     * @param count 总数
     * @returns {Array} 返回一个页数数组
     */
    function pageNum(mpage,count){

        //每页显示数据
        var page = Number(mpage);

        //总数据数
        var counts = Number(count);
        if((counts%page) === 0){
            allPage = counts/page;
        } else {
            allPage = Math.ceil(counts/page);
        }

        //页码
        var pagenumarr = [];
        if(allPage > 10){
            pagenumarr = [1,2,3,4,5,6,7,8,9,10];
        } else {
            for(var i = 1; i <= allPage; i++){
                pagenumarr.push(i);
            }
        }

        return pagenumarr;
    }

    /**
     * 按页数号分页
     */
    $scope.getPageNum = function(target){

        //要查的页数
        var thispage = $(target).text();
        $scope.isShowClass = thispage;
        thispage = Number(thispage);

        //请求数据
        getPage(thispage);

        //样式控制
        switch (thispage){
            case 1:
                $scope.isDisabledPrev = true;
                $scope.isDisabledNext = false;
                break;
            case allPage:
                $scope.isDisabledNext = true;
                $scope.isDisabledPrev = false;
                break;
            default:
                $scope.isDisabledNext = false;
                $scope.isDisabledPrev = false;
        }
    };

    /**
     * 前一页
     */
    $scope.upPage = function(target){
        //需要到的页数
        var thispage = $(target).parents(".pagination").find(".active").text();
        thispage = Number(thispage) - 1;

        if(thispage > 1){
            getPage(thispage);
            $scope.isShowClass = thispage;
            $scope.isDisabledNext = false;
        } else if(thispage === 1){
            getPage(1);
            $scope.isShowClass = thispage;
            $scope.isDisabledPrev = true;
        } else {
            $scope.isDisabledPrev = true;
        }

    };

    /**
     * 后一页
     */
    $scope.downPage = function(target){
        //需要到的页数
        var thispage = $(target).parents(".pagination").find(".active").text();
        thispage = Number(thispage) + 1;

        if(thispage < allPage){
            getPage(thispage);
            $scope.isShowClass = thispage;
            $scope.isDisabledPrev = false;

        } else if(thispage === allPage){
            getPage(thispage);
            $scope.isShowClass = thispage;
            $scope.isDisabledNext = true;
        }
    };

    /**
     * 第一页
     */
    $scope.firstPage = function(target){
        var _isDisabled = $(target).hasClass("disabled");
        if(!_isDisabled){
            getPage(1);
            $scope.isShowClass = 1;
            $scope.isDisabledPrev = true;
            $scope.isDisabledNext = false;
        }
    };

    /**
     * 最后一页
     */
    $scope.lastPage = function(target){
        var _isDisabled = $(target).hasClass("disabled");
        if(!_isDisabled){
            getPage(allPage);
            $scope.isShowClass = allPage;
            $scope.isDisabledNext = true;
            $scope.isDisabledPrev = false;
        }
    };

    /**
     * 分页数据获取函数
     * @param thispage 当前页数
     */
    function getPage(thispage){

        if(allPage > 10){
            var pageArrQ = 1; //起始页码
            var pageArrZ = 1; //最大页码

            if((thispage - 5) > 0){
                pageArrQ = thispage - 5;
            }
            if((thispage + 4) <= allPage){
                pageArrZ = thispage + 4;
                if(pageArrZ < 10){
                    pageArrZ = 10;
                }
            } else {
                pageArrZ = allPage;
            }
            if((pageArrZ - pageArrQ) !== 9){
                pageArrQ = pageArrZ - 9;
            }

            var pagenumArr = [];
            for(var i = pageArrQ; i <= pageArrZ; i++){
                pagenumArr.push(i);
            }

            $scope.pagenums = pagenumArr;

        }

        var pageData = data;
        pageData.page = thispage;

        uuHttp.get({url:$scope.pageDataUrl,data:pageData}).then(function(data){
            //处理数据区间显示
            if(data.code === 0){
                uploadData(data.data,"page");
                $scope.startdata = (Number(thispage)-1 === 0) ? 1 : (Number(thispage)-1) * Number($scope.mpages) + 1;
                if ((Number(thispage) * Number($scope.mpages)) > Number($scope.counts)) {
                    $scope.enddata = $scope.counts;
                } else {
                    $scope.enddata = Number(thispage) * Number($scope.mpages);
                }
            } else if(data.code <= 4){
                window.location.href =  loginUrl;
            } else {
                alert(data.message);
            }
        });

    }

    /****************************************************************************************
     *                                      表格操作
     *****************************************************************************************/

    /**
     * 按钮处理事件
     * @param operate 操作值
     */
    $scope.btnTypes = function(operate){
        var hash = window.location.hash;

        switch (operate.type){
            case "url" :
                if(operate.ajaxurl !== ""){
                    dataUrl.dataUrl = operate.ajaxurl;
                    sessionStorage.urlFormData = operate.ajaxurl;
                    window.location.href = '#/upform';
                }

                break;
            case "table" :
                if(operate.ajaxurl !== ""){
                    dataUrl.dataUrl = operate.ajaxurl;
                    sessionStorage.urlTableData = operate.ajaxurl;
                    if(hash === "#/uptable"){
                        $scope.pageDataUrl = dataUrl.dataUrl;
                        getInitDate(dataUrl.dataUrl);
                    } else {
                        window.location.href = '#/uptable';
                    }
                }

                break;
            case "del" :
                if(operate.ajaxurl !== ""){
                    delTableData(operate.ajaxurl);
                }
                break;
            case "iframe" :
                //$scope.iframeurl = $sce.trustAsResourceUrl(operate.value);
                $("#tableIframe").attr('src', operate.value);
                $scope.title = operate.title;
                $scope.ajaxurl = operate.ajaxurl;
                $(".formwin").show();
                break;
            case "frame" :
                $("#navFrame").attr('src', operate.ajaxurl).show();
                break;
            case "state" :
                $scope.confirmtext = operate.value;
                $scope.title = operate.title;
                $scope.ajaxurl = operate.ajaxurl;
                $(".confirm").show();
                break;
            case "detail" :
                if(operate.ajaxurl !== ""){
                    dataUrl.dataUrl = operate.ajaxurl;
                    sessionStorage.urlDetail = dataUrl.dataUrl;
                    window.location.href = '#/yh/yhlb';
                }
                break;
            case "complain" :
                if(operate.ajaxurl !== ""){
                    dataUrl.dataUrl = operate.ajaxurl;
                    sessionStorage.urlComplain = dataUrl.dataUrl;
                    window.location.href = '#/yh/yhts';
                }
                break;
            case "location" :
                window.location.href = updateUrlParam(window.location.href.split("#")[0], "navurl", encodeURIComponent(operate.ajaxurl));
                break;
        }
    };

    /**
     * 状态更改的提交
     * @param id 数据ID
     * @param url 提交地址
     */
    $scope.confirmOK = function(id,url){
        uuHttp.get({url: url}).then(function(data){
            if(data.code === 0){
                getInitDate($scope.pageDataUrl);
                $(".confirm").hide();
            } else if(data.code <= 4){
                window.location.href =  loginUrl;
            } else {
                alert(data.message)
            }

        });
    };

    /**
     * 获取iframe里面的值
     * @param url
     */
    $scope.getIframeValue = function(url){
        if(url === "" || url === "undefined"){
            $(".formwin").hide();
        } else {
            var data = tableIframe.window.getValue();
            console.log(data);
            uuHttp.get({url: url, data: data}).then(function(data){
                if (data.code === 0) {
                    $(".confirm").hide();
                } else if(data.code <= 4){
                    window.location.href =  loginUrl;
                }
            });
        }

    };

    /**
     * 图片弹窗
     */
    $scope.winImg = function(target){
        $scope.imgUrl = $(target).attr("src");
        $(".winbigimg").show();
    };

    //关闭弹窗
    $scope.colseWin = function(target){
        $(target).parents(".event-tc").hide();
    };

    /**
     * 排序
     * @param target
     * @param name
     */
    $scope.tableSort = function(target,name){

        var $eventI = $(target).children();
        var $sortCur = $(".sortCur");
        if($eventI.hasClass("fa-sort")){
            sortInit();
            $eventI.removeClass().addClass("fa fa-sort-asc");
        } else if($eventI.hasClass("fa-sort-asc")){
            sortInit();
            $eventI.removeClass().addClass("fa fa-sort-desc");
        } else {
            sortInit();
            $eventI.removeClass().addClass("fa fa-sort-asc");
        }

        function sortInit(){
            $sortCur.each(function(){
                $sortCur.children().removeClass().addClass("fa fa-sort");
            });
        }
    };


    /******************************************************************
     *                              搜索模块
     ******************************************************************/
    $scope.tableSearch = function(type,target){
        data = {};
        switch (type){
            case "group" :
                data[$(target).attr("data-name")] = $(target).attr("data-value");
                break;
            default :
                $("#tableSearch").find(".event-searchValue").each(function(){
                    data[$(this).attr("name")] = $(this).val();
                });
        }

        if($scope.searchs.method === "get"){
            uuHttp.get({url:$scope.searchs.ajaxUrl,data:data}).then(function(data){
                if (data.code === 0) {
                    uploadData(data.data);
                } else if(data.code <= 4){
                    window.location.href =  loginUrl;
                }
            });
        }

    };

}]).directive('uuTable', ['$compile', function($compile){

    /**
     * 连接函数
     * @param scope 作用域
     * @param element  作用元素
     * @param attr  元素属性
     */
    function link(scope, element, attr){

        /**
         * 创建表格
         * @param columnth  表头
         * @param columntd  表格
         * @param search    搜索
         */
        function createTable(columnth,columntd,search){
            //绑定作用域
            scope.columnth = columnth;
            scope.columntd = columntd;
            scope.search = search;

            var searchStr = '',theadStr = '',tbodyStr = '';

            //搜索
            if(scope.search){
                searchStr = '<div id="tableSearch" class="tableSearch"><button id="btnSearch" type="button" class="btnSearchR btn btn-bm btn-purple" ng-click="tableSearch()">搜索 <i class="fa fa-search icon-on-right bigger-110"></i> </button>';

                for(var i = 0; i < search.searchPro.length; i++){
                    var searchProI = search.searchPro[i];

                    switch (searchProI.type){
                        case "input" :
                            searchStr += '<div class="search-ground"> ' +
                            '<label class="search-label" ng-if="search.searchPro['+ i +'].label">{{search.searchPro['+ i +'].label}}</label> ' +
                            '<input type="text" name="{{search.searchPro['+ i +'].name}}" class="search-query event-searchValue" placeholder="{{search.searchPro['+ i +'].options[0].text}}" value=""> ' +
                            '</div>';
                            break;
                        case "select" :
                            searchStr += '<div class="search-ground"> ' +
                            '<label class="search-label" ng-if="search.searchPro['+ i +'].label">{{search.searchPro['+ i +'].label}}</label> ' +
                            '<select class="search-select event-searchValue" name="{{search.searchPro['+ i +'].name}}"> ' +
                            '<option ng-repeat="option in search.searchPro['+ i +'].options" value="{{option.value}}" >{{option.text}}</option> ' +
                            '</select> ' +
                            '</div>';
                            break;
                        case "group" :
                            searchStr += '<div class="search-group">' +
                            '<label class="search-label" ng-if="search.searchPro['+ i +'].label">{{search.searchPro['+ i +'].label}}</label> ' +
                            '<ul>'+
                            '<li ng-repeat="option in search.searchPro['+ i +'].options"" data-name="{{search.searchPro['+ i +'].name}}" data-value="{{option.value}}" ng-click="tableSearch(search.searchPro['+ i +'].type,$event.target)">{{option.text}}</li> ' +
                            '</ul> ' +
                            '</div>';
                            break;
                        case "time" :
                            searchStr += '<div class="search-ground"> ' +
                            '<label class="search-label" ng-if="search.searchPro['+ i +'].label">{{search.searchPro['+ i +'].label}}</label> ' +
                            '<input type="date" name="{{search.searchPro['+ i +'].name}}" class="search-query event-searchValue" placeholder="{{search.searchPro['+ i +'].options[0].text}}" value=""> ' +
                            '</div>';
                            break;
                    }
                }

                searchStr += '</div>';
            }

            //表头
            if(scope.columnth){
                theadStr = ' <table id="uuLeeDataTable" class="display uuLeeDataTable"><thead><tr>';

                for(var h = 0; h < columnth.length; h++){
                    switch (columnth[h].isSort){
                        case "true" :
                            theadStr += '<th ng-click="tableSort($event.target,\''+columnth[h].fieldEn+'\')" class="sortCur">'+ columnth[h].fieldCn +'<i class="fa fa-sort"></i></th>';
                            break;
                        case "asc" :
                            theadStr += '<th ng-click="tableSort($event.target,\''+columnth[h].fieldEn+'\')" class="sortCur">'+ columnth[h].fieldCn +'<i class="fa fa-sort-asc"></i></th>';
                            break;
                        case "desc":
                            theadStr += '<th ng-click="tableSort($event.target,\''+columnth[h].fieldEn+'\')" class="sortCur">'+ columnth[h].fieldCn +'<i class="fa fa-sort-desc"></i></th>';
                            break;
                        default:
                            theadStr += '<th>'+ columnth[h].fieldCn +'</th>';

                    }
                }

                theadStr += "</thead></tr>";
            }

            //表格
            if(scope.columntd.length){
                tbodyStr = '<tbody><tr ng-repeat="td in columntd" data-id="{{td.id}}"  ng-class="{even: $even, odd: $odd}">';

                for(var d = 0; d < columnth.length; d++){
                    switch (columnth[d].type){
                        case "text" :
                            tbodyStr += '<td>{{td.'+ columnth[d].fieldEn +'}}</td>';
                            break;
                        case "img" :
                            tbodyStr += '<td><img ng-src="{{td.'+ columnth[d].fieldEn +'}}" class="event_imgurl" ng-click="winImg($event.target)"/></td>';
                            break;
                        case "imgs" :
                            for(var n = 0; n < columntd.length; n++){
                                columntd[n][columnth[d].fieldEn] = columntd[n][columnth[d].fieldEn].split(";");
                            }
                            tbodyStr += '<td><img ng-repeat="img in td.'+ columnth[d].fieldEn +'" ng-src="{{img}}" class="event_imgurl" ng-click="winImg($event.target)"/></td>';
                            break;
                        case "filter" :
                            tbodyStr += '<td><span class="label {{td.'+ columnth[d].fieldEn +' | '+columnth[d].filter+':1}}">{{td.'+ columnth[d].fieldEn +' | '+columnth[d].filter+':2}}</span></td>';
                            break;
                        case "operates" :
                            tbodyStr += '<td><a href="" ng-repeat="operate in td.'+ columnth[d].fieldEn +'" class="btn fa {{operate.stylecss}}" ng-click="btnTypes(operate)">{{operate.name}}</a></td>';
                            break;
                        case "colorDiv" :
                            tbodyStr += '<td><div style="width:55px;height:22px;background-color: {{td.'+ columnth[d].fieldEn +'}}"></div></td>';
                            break;
                    }
                }

                tbodyStr += "</tr></tbody>";
            } else {
                tbodyStr = '<tbody><tr><td colspan="{{columnth.length}}"><div style="text-align: center;">暂无数据</div></td></tr></tbody>';
            }

            //转换成JQuery对象
            var $div = $(searchStr + theadStr + tbodyStr);

            //追加DIV
            $compile($div)(scope);
            element.html("").prepend($div);

        }

        scope.$on("render.table", function(obj,args){
            createTable(args.columnth,args.columntd,args.search);
        });

    }

    return {
        restrict: 'A',
        link: link
    };
}]).filter('filterText01', function () {
    return function(value,type){

        if(type == 1){
            switch (value){
                case "0" :
                    return "label-danger";
                    break;
                case "1" :
                    return 'label-success';
                    break;
            }
        } else if(type == 2){
            switch (value){
                case "1" :
                    return "显示";
                    break;
                case "2" :
                    return '隐藏';
                    break;
            }
        }

    }
}).filter('filterText02', function () {
    return function(value,type){

        if(type == 1){
            switch (value){
                case "0" :
                    return "label-danger";
                    break;
                case "1" :
                    return 'label-success';
                    break;
            }
        } else if(type == 2){
            switch (value){
                case "1" :
                    return "是";
                    break;
                case "2" :
                    return '否';
                    break;
            }
        }

    }
});
