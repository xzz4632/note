var publicUrl = 'http://oapi.playwx.com/',
    loginUrl = 'http://bp.playwx.com/site/login?redirect_url=' + encodeURIComponent(window.location.href.split("#")[0]),
    qrTime,
    apiUrl="https://oapi.playwx.com/oxcms/",
    //apiUrl="http://10.0.60.97:8080/oxcms/",
    SE = 'ADUU_MANAGE_J_SESSIONID',
    navData = "",
    routerStr = "$routeProvider",
    routerChangeStr = "switch (window.location.hash){";

function getQueryStringArgs(){
    var qs = (location.search.length > 0 ? location.search.substring(1) : ""),
        args = {},
        items = qs.length ? qs.split("&") : [],
        item = null,
        name = null,
        value = null,
        i = 0,
        len = items.length;

    for(i = 0; i < len; i++){
        item = items[i].split("=");
        name = decodeURIComponent(item[0]);
        value = decodeURIComponent(item[1]);
        if(name.length){
            args[name] = value;
        }
    }
    return args;
}

function getSE(){
    var _se = sessionStorage.getItem(SE);

    if(_se){
        return _se;
    } else {
        return "";
    }
}

var args = getQueryStringArgs();

function init(){
    $(function(){

        var _navUrl = apiUrl + "manage/nav/main?projid="+ args.projid +"&se="+getSE();

        if(args.navurl){
            _navUrl = decodeURIComponent(args.navurl) + "&se="+getSE();
        }

        $.ajax({
            type: 'GET',
            url: _navUrl,
            async: false,
            xhrFields: {
                withCredentials: true
            },
            dataType: "json",
            success: function (data) {

                if(data.code === 0){
                    var _d = data.data,
                        navArr = [
                            {
                                href: "/uptable",
                                type: "table",
                                isDef: true,
                                sApi: "sessionStorage.urlTableData"
                            },
                            {
                                href: "/upform",
                                type: "form",
                                isDef: true,
                                sApi: "sessionStorage.urlFormData"
                            }
                        ],
                        i = 0;

                    navData = _d;

                    if(_d.length){
                        forOne:
                        for(i = 0; i < _d.length; i++){
                            if(_d[i].nav){
                                for(var n = 0; n < _d[i].nav.length; n++){
                                    if(_d[i].nav[n].nav){
                                        for(var m = 0; m < _d[i].nav[n].nav.length; m++){
                                            if(_d[i].nav[n].nav[m].className && _d[i].nav[n].nav[m].className === "active"){
                                                navArr.push({
                                                    href: "/",
                                                    type: _d[i].nav[n].nav[m].type,
                                                    dataUrl: _d[i].nav[n].nav[m].dataUrl
                                                });
                                                break forOne;
                                            }
                                        }
                                    } else if(_d[i].nav[n].className && _d[i].nav[n].className === "active"){
                                        navArr.push({
                                            href: "/",
                                            type: _d[i].nav[n].type,
                                            dataUrl: _d[i].nav[n].dataUrl
                                        });
                                        break forOne;
                                    }
                                }
                            } else if(_d[i].className && _d[i].className === "active"){
                                navArr.push({
                                    href: "/",
                                    type: _d[i].type,
                                    dataUrl: _d[i].dataUrl
                                });
                                break;
                            }
                        }
                    }

                    for(i = 0; i < _d.length; i++){
                        if(_d[i].nav){
                            for(var n = 0; n < _d[i].nav.length; n++){
                                if(_d[i].nav[n].nav){
                                    navArr = navArr.concat(_d[i].nav[n].nav);
                                } else {
                                    navArr = navArr.concat(_d[i].nav[n]);
                                }
                            }
                        } else {
                            navArr = navArr.concat(_d[i]);
                        }
                    }

                    for(i = 0; i < navArr.length; i++){
                        routerStr += '.when("' + navArr[i].href + '", {' +
                            '                    templateUrl: "public/views/' + navArr[i].type + '.html",' +
                            '                    controller: "' + navArr[i].type +'Contr"'+
                            '                })';

                        routerChangeStr += 'case "#'+ navArr[i].href +'":';

                        if(navArr[i].isDef){
                            routerChangeStr += 'if(!dataUrl.dataUrl){' +
                                'dataUrl.dataUrl = '+ navArr[i].sApi +'}';
                        } else {
                            routerChangeStr += 'dataUrl.dataUrl = "' + navArr[i].dataUrl +'";';
                        }
                        routerChangeStr += 'break;';

                    }
                    routerStr += ";";
                    routerChangeStr += "}";

                    angular.bootstrap(document,['uuApp']);
                } else {
                    alert(data.message);
                }

            }
        });



        $("body").on("click", function(e){
            var target = e.target;

            //菜单的切换交互
            var sidebarNav = $(target).parents("#sidebarNav").length;
            if(sidebarNav !== 0){
                if($(target).hasClass("uuNavTop") || $(target).parents(".uuNavTop").length > 0){
                    return;
                } else {
                    var subMenu = $(target).closest("a").siblings(".submenu").length;
                    if (subMenu === 0) {
                        var navLi = $(target).closest("#sidebarNav").find("li");
                        for (var i = 0; i < navLi.length; i++) {
                            if ($(navLi[i]).hasClass("open")) {

                            } else {
                                $(navLi[i]).removeClass("active");
                            }
                        }
                        $(target).closest("li").toggleClass("active");
                    } else {
                        var liSib = $(target).closest("li").toggleClass("active open").siblings();
                        for (var l = 0; l < liSib.length; l++) {
                            if ($(liSib[l]).find(".submenu").length === 0) {

                            } else {
                                $(liSib[l]).removeClass("active open");
                            }
                        }
                    }
                }
            }
            //菜单的收放
            var sidebarCollapse = $(target).closest("#sidebar-collapse").length;
            if(sidebarCollapse !== 0){
                $("#sidebar").toggleClass("menu-min");
                if($(target).children().length === 0){
                    $(target).toggleClass("fa-angle-double-left fa-angle-double-right");
                } else {
                    $(target).children().toggleClass("fa-angle-double-left fa-angle-double-right");
                }
            }
        }).on("click", ".event-frame", function(){
            $("#navFrame").show();
        }).on("click", '.event-router', function(){
            $("#navFrame").hide();
        });

    })
}

init();