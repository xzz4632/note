/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
    config.toolbar = [
        ['Maximize','-','Paste','PasteText','PasteFromWord'],
        ['Bold','Italic','Image','Link','Unlink'],
        ['NumberedList','BulletedList','-','Outdent','Indent'],
        ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
        ['Table','HorizontalRule','FontSize','TextColor','BGColor']
    ];

    config.removeDialogTabs = 'image:advanced;link:advanced';
    config.image_previewText = ' ';
    config.filebrowserUploadUrl = 'http://oapi.playwx.com/api/res/UploadFile.do?token=1c954693fbedf5bb517bc2e3d21b3a25&fileType=1';
    config.filebrowserImageUploadUrl = 'http://oapi.playwx.com/api/res/UploadFile.do?token=1c954693fbedf5bb517bc2e3d21b3a25&fileType=1&isCk=1';
};
