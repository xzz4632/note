var MiniSite = new Object();
MiniSite.Browser={
    ie:/msie/.test(window.navigator.userAgent.toLowerCase()),
    moz:/gecko/.test(window.navigator.userAgent.toLowerCase()),
    opera:/opera/.test(window.navigator.userAgent.toLowerCase()),
    safari:/safari/.test(window.navigator.userAgent.toLowerCase())
};

MiniSite.JsLoader={
    load:function(sUrl,fCallback,time){
	   if(typeof(time)=='undefined') time=0;
	   var _script=document.createElement('script');
	   _script.setAttribute('charset','UTF-8');
	   _script.setAttribute('type','text/javascript');
	   _script.setAttribute('src',sUrl);
	   _script.setAttribute('id','load_data');
	   document.getElementsByTagName('head')[0].appendChild(_script);	   
	   if(MiniSite.Browser.ie){
		  _script.onreadystatechange=function(){
			 if(this.readyState=='loaded'||this.readyState=='complete'){
				time==0?fCallback():setTimeout(fCallback,time);
			 }
		  };
	   }else if(MiniSite.Browser.moz){
			_script.onload=function(){
				time==0?fCallback():setTimeout(fCallback,time);
		    };
	   }else{
			time==0?fCallback():setTimeout(fCallback,time);
	   }
    },
	post:function(url,paramStr,fCallback,async){
		var xmlhttp=null;
		if (window.XMLHttpRequest){
		    xmlhttp=new XMLHttpRequest();
		}else if(window.ActiveXObject){
			 var versions = ['Microsoft.XMLHTTP', 'MSXML.XMLHTTP',
			 'Microsoft.XMLHTTP', 'Msxml2.XMLHTTP.7.0',
			 'Msxml2.XMLHTTP.6.0', 'Msxml2.XMLHTTP.5.0',
			 'Msxml2.XMLHTTP.4.0', 'MSXML2.XMLHTTP.3.0',
			 'MSXML2.XMLHTTP'];

			 for ( var i = 0; i < versions.length; i++) {
				try {
					xmlHttp = new ActiveXObject(versions[i]);
					break;
				}catch(e){}
			 }
		}
		if(xmlhttp!=null){
		  xmlhttp.onreadystatechange=function(){
			  if (xmlhttp.readyState==4){
				  if (xmlhttp.status==200)
					{
					   var data=xmlhttp.responseText;
					   try{  
						  fCallback(data);
					   }catch(e){}
					}
			  }
		  };
		  xmlhttp.open("POST",url,async ? async : true);
		  xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		  xmlhttp.send(paramStr);
		}else{
		  alert("Your browser does not support XMLHTTP.");
		}
	}
};

function getQS(str,name) {
	try{
		var kv=str.split('&');
		for(var i=0;i<kv.length;i++){
			kandv=kv[i].split("=");
			if(kandv[0]==name){
				return kandv[1];	
			}
		}
	}catch(e){}
	return null;
}

function getQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) return unescape(r[2]); 
	return null;
}


function removeSessionid(url){
	if(url.indexOf('#')!=-1){
		url=url.substring(0,url.indexOf('#'));
	}
	if(url.indexOf('?')==-1){
		return url;
	}
	var head=url.substring(0,url.indexOf('?'));
	var queryStr=url.substring(url.indexOf('?')+1);
	var qs=queryStr.split('&');
	for(var i=qs.length-1;i>=0;i--){
		if(qs[i].indexOf('se=')!=-1)
			qs.splice(i,1);
	}
	queryStr=qs.join('&');
	queryStr=queryStr.replace(/&&/g,'&');
	if(queryStr==null||queryStr=='')
		return head
	else
		return head+'?'+queryStr;
}

function encodeJsonComponent(json){
   json = replaceAllEx(json,'=','~');
   json = replaceAllEx(json,'=','~');
   return json;
}


function replaceAllEx(text, oldChar, newChar){
   var index = text.indexOf(oldChar);
   var json = "";
   while(index!=-1){
	  json  = json + text.substring(0,index)+newChar;
	  text  = text.substring(index+1,text.length);
	  index = text.indexOf(oldChar);
   }
   json = json + text;
   return json;
}

function userInvalLogin(message){
	make_winAlert("alert",message,forwardLogin);
}

function forwardLogin(oauthtoken,pdid,merid,channel,wxid){
	var queryStr='oauthtoken='+oauthtoken+'&pdid='+pdid+'&merid='+merid+'&channel='+channel+'&wxid='+wxid;
	window.location.href=SELF_HOST+'login.html?'+queryStr+'&backurl='+encodeURIComponent(removeSessionid(window.location.href));
}

function toLogin(merid){
	var queryStr='merid='+merid;
	window.location.href=SELF_HOST+'login.html?'+queryStr+'&backurl='+encodeURIComponent(removeSessionid(window.location.href))+'&'+Math.random();
}

function goto(html){
	var selfurl=window.location.href;
	var queryStr=selfurl.substring(selfurl.indexOf('?')+1);
	if(html.indexOf('?')==-1)
		window.location.href=removeSessionid(html+'?'+queryStr);
	else
		window.location.href=removeSessionid(html+'&'+queryStr);
}

function isWeiXin(){ 
	var ua = window.navigator.userAgent.toLowerCase(); 
	if(ua.match(/MicroMessenger/i) == 'micromessenger'){ 
		return true; 
	}else{
		return false; 
	} 
}

function getSe(merid){
	se=window.sessionStorage.getItem(SE+merid);
	return se;	
}

/*
向url中添加参数,如果已存在参数则更新参数值
*/
function updateUrlParam(url,paramName,paramValue){
	if (/\?/g.test(url)) {
		var reg = new RegExp("([?&]+)" + paramName + "=([^&]*)","gi");
		var rs = reg.exec(url);
		if(rs){
			url = url.replace(reg,rs[1]+paramName+"="+paramValue);
		}else{
			url += "&" + paramName + "=" + paramValue;
		}
	} else if(paramName)	{
		url += "?" + paramName + "=" + paramValue;
	}
	return url;
}